#include <optional>
#include <vector>
#include <string>
#include <memory>
#include <stack>

#include <raylib.h>
#include <raymath.h>

constexpr int xdim = 8;
constexpr int ydim = 8;
constexpr int size = 32;
constexpr Color white_square{ 192,192,192, 255 };
constexpr Color black_square{ 96, 96, 96, 255 };
constexpr Color white_piece{ 255,255,255, 255 };
constexpr Color black_piece{ 16, 16, 16, 255 };
const Color highlight_good{ 255,255,64,128 };
const Color highlight_bad{ 255,0,0,128 };

#undef BLACK
#undef WHITE

enum Player { BLACK, WHITE };

struct Square
{
    int x;
    int y;
};

class GameBoard
{
private:
    std::optional<Player> board[ydim][xdim];
public:
    std::optional<Player> GetAt(Square tile) { return board[tile.y][tile.x]; }
    void SetAt(Square tile, std::optional<Player> p) { board[tile.y][tile.x] = p; }
};

class DrawGameBoard {
private:
    GameBoard* board;
    void DrawPiece(Square t, Color c) {
        DrawCircle(t.x + size / 2 + 3, t.y + size / 2 + 3, size / 2 - 4, Color{ 0,0,0,64 });
        DrawCircle(t.x + size / 2, t.y + size / 2, size / 2 - 4, c);
    }

public:
    DrawGameBoard(GameBoard* b) : board{ b } {}
    void Draw() {
        for (int y = 0; y < ydim; ++y) {
            for (int x = 0; x < xdim; ++x) {
                Color square = (x + y) % 2 == 0 ? black_square : white_square;
                DrawRectangle(x * size, y * size, size, size, square);

                if (auto p = board->GetAt({ x, y })) {
                    Color piece = p.value() == WHITE ? white_piece : black_piece;
                    DrawPiece({ x * size, y * size }, piece);
                }
            }
        }
    }
};



class GameState {
public:
    enum {
        PICK_A_PIECE,
        MOVE_A_PIECE,
        JUMP_A_PIECE
    };
    using State = decltype(PICK_A_PIECE);
    GameState() {
        Reset();
    }

    void Reset() {
        player = WHITE;
        state = PICK_A_PIECE;
    }

    Player OtherPlayer()const {
        if (player == WHITE)return BLACK; else return WHITE;
    }

    Player player;
    State state;
};



class DrawGameUI
{
private:
    DrawGameBoard* db;
    GameState* state;
    int ui_width;
    int ui_height;
    Color backdrop;
public:
    DrawGameUI(DrawGameBoard* d, GameState* s, int uw, int uh) :db{ d }, state{ s }, ui_width { uw }, ui_height{ uh }, backdrop{ 160,16,16,255 } {}
    void Draw() {
        ClearBackground(RAYWHITE);
        DrawRectangle(size * xdim, 0, ui_width, ui_height, backdrop);
        //Draw text
        const char* player[]{ "WHITE","BLACK" };
        Color block_icon[] = { Color{255,255,255,255},Color{0,0,0,255} };

        int pidx = 0;
        if (state->player == BLACK) {
            pidx = 1;
        }

        const Color textcolour = Color{ 255,255,255,255 };
        std::string output = player[pidx] + std::string("'S Turn");
        constexpr int font_sz = 8;
        constexpr int block_sz = 8;
        DrawText(output.c_str(), size * xdim + size, size, font_sz, textcolour);
        DrawRectangle(size * xdim + size - font_sz * 2 - 4, size - font_sz / 2, font_sz * 2, font_sz * 2, block_icon[pidx]);



        db->Draw();
    }
};

class GameRules {
    //GameState* state;
    GameBoard* board;

    //if jump,

    std::vector<Square> GetValidMoves(Square tile, Player player, GameState::State state) const {
        std::vector<Square> off;//{ { {-2,-2},{-2,2},{2,-2},{2,2} } };
        if (player == WHITE)
            off = { { {-1,1},{1,1} } };
        else
            off = { { {-1,-1},{1,-1} } };

        std::vector<Square> moves;

        if(state== GameState::JUMP_A_PIECE){
        //for each offset
            for (auto o : off) {
                //Check jump
                Square p = { o.x * 2 + tile.x ,o.y * 2 + tile.y };
                if (p.x < 0 || p.x >= xdim || p.y < 0 || p.y >= ydim)
                    continue;
                Square jump = { o.x + tile.x ,o.y + tile.y };
                //If we jump an opponents piece, it's valid
                if (board->GetAt(jump).has_value() && board->GetAt(jump).value() != player)
                    moves.push_back(p);
            }
        }

        //If we CAN jump we have to.
        if (!moves.empty())
            return moves;

        if (state == GameState::MOVE_A_PIECE) {
            for (auto o : off) {
                //Check diagonals
                Square p = { o.x + tile.x ,o.y + tile.y };
                if (p.x < 0 || p.x >= xdim || p.y < 0 || p.y >= ydim)
                    continue;
                //If no piece in place
                if (!board->GetAt(p))
                    moves.push_back(p);
            }
        }
        return moves;
    }

public:
    GameRules(GameState* s, GameBoard* b) : board{ b } {}

    void InitBoard() {
        for (int i = 0; i < 12; ++i) {
            int y = (i * 2) / xdim;
            int x = (i * 2 + y) % xdim;
            board->SetAt({ x,y }, WHITE);
        }

        for (int i = 0; i < 12; ++i) {
            int y = (i * 2) / xdim;
            int x = (i * 2 + y + 1) % xdim;
            board->SetAt({ x,ydim - y - 1 }, BLACK);
        }
    }

    bool CanPlayMove(Player player, Square start, Square end, GameState::State state) const {

        //tile must be empty, midway tile must be another piece
        auto p = board->GetAt(start);

        // It start tile empty? bail
        if (!p)
            return false;

        //If not correct players piece, bail
        if (player != p.value())
            return false;

        //If target is not empty, bail
        if (board->GetAt(end))
            return false;

        //Is it a valid move? 
        auto moves = GetValidMoves(start, player,state);

        for (auto m : moves) {
            if (m.x == end.x && m.y == end.y)
                return true;
        }
        return false;
    }

    bool CanMove(Player p, Square start, GameState::State state) const {
        //No piece here?
        if (!board->GetAt(start))
            return false;

        auto mv = GetValidMoves(start, p,state);

        for (auto m : mv)
            if (CanPlayMove(p, start, m,state))
                return true;

        return false;
    }
};

class UserInterface
{
private:
    GameBoard* board;
    GameState* state;
    const GameRules* rules;



    Square start;
    Square current_tile;

    void DrawTile(Square tile, Color h) {
        DrawRectangle(tile.x * size, tile.y * size, size, size, h);
    }

    void UpdateMouse() {
        auto mp = GetMousePosition();

        //map to a tile
        mp.x = (int)(mp.x / size);
        mp.y = (int)(mp.y / size);

        current_tile = Square{ (int)mp.x,(int)mp.y };

        //Bail if not clicking on the board
        if (current_tile.x >= xdim || current_tile.y >= ydim)
            return;

        //RMB to reset move
        int mc = IsMouseButtonPressed(MouseButton::MOUSE_BUTTON_RIGHT);
        if (mc) {
            state->state = GameState::PICK_A_PIECE;
            return;
        }

        //LMB to make/confirm a move
        mc = IsMouseButtonPressed(MouseButton::MOUSE_BUTTON_LEFT);
        if (!mc)
            return;

        switch (state->state) {
        case GameState::PICK_A_PIECE:
            if (auto piece = board->GetAt(current_tile)) {
                if (rules->CanMove(state->player, current_tile,GameState::JUMP_A_PIECE)) {
                    start = current_tile;
                    state->state = GameState::JUMP_A_PIECE;
                } else if (rules->CanMove(state->player, current_tile,GameState::MOVE_A_PIECE)) {
                    start = current_tile;
                    state->state = GameState::MOVE_A_PIECE;
                }
            }
            break;

        case GameState::MOVE_A_PIECE:
            if (rules->CanPlayMove(state->player, start, current_tile, GameState::MOVE_A_PIECE)) {
                board->SetAt(current_tile, state->player);
                board->SetAt(start, {});
                state->player = state->OtherPlayer();
                state->state = GameState::PICK_A_PIECE;
            }
            break;

        case GameState::JUMP_A_PIECE:
            if (rules->CanPlayMove(state->player, start, current_tile, GameState::JUMP_A_PIECE)) {
                //Switch states and player
                Square half = { (start.x + current_tile.x) / 2,(start.y + current_tile.y) / 2 };
                auto sp = board->GetAt(half);
                board->SetAt(half, {});
                board->SetAt(current_tile, state->player);
                board->SetAt(start, {});
                if (!rules->CanMove(state->player, current_tile, GameState::JUMP_A_PIECE)) {
                    state->player = state->OtherPlayer();
                    state->state = GameState::PICK_A_PIECE;
                }
                else {
                    //Reset the move for multi-jumps
                    start = current_tile;
                }
            }
            break;
        }
    }

    void UpdateKeyboard(){
        
    }

public:
    UserInterface(GameBoard* b, GameState* s, const GameRules* r) : board{ b }, state{ s }, rules{ r } {}

    void Update(){
        UpdateMouse();
        UpdateKeyboard();
    }

    void Draw() {
        switch (state->state) {
        case GameState::PICK_A_PIECE:
        {
            auto piece = board->GetAt(current_tile);
            if (!piece)
                break;

            auto can_jump = rules->CanMove(state->player, current_tile, GameState::JUMP_A_PIECE);
            auto can_move = !can_jump ? rules->CanMove(state->player, current_tile, GameState::MOVE_A_PIECE) : false;

            if (piece == state->player && (can_jump || can_move)) {
                DrawTile(current_tile, highlight_good);
            }
            else
                DrawTile(current_tile, highlight_bad);
            break;
        }
        default:
        {
            if (rules->CanPlayMove(state->player, start, current_tile,state->state)) {
                DrawTile(current_tile, highlight_good);
                DrawLine(start.x * size + size / 2, start.y * size + size / 2, current_tile.x * size + size / 2, current_tile.y * size + size / 2, highlight_good);
            }
            break;
        }
        }
    }
};

int main() {
    const int uiw = 256;

    //UndoSystem undos;
    GameBoard board;
    GameState state;
    DrawGameBoard db(&board);
    DrawGameUI dui{ &db,&state, uiw,size * ydim };
    GameRules rules{ &state,&board };
    UserInterface ui{ &board,&state,&rules };// , & undos

    rules.InitBoard();

    SetConfigFlags(FLAG_MSAA_4X_HINT);
    InitWindow(size * xdim + uiw, size * ydim, "Checkers");
    while (!WindowShouldClose()) {

        ui.Update();

        BeginDrawing();
        dui.Draw();
        ui.Draw();
        EndDrawing();
    }
    CloseWindow();
    return 0;
}